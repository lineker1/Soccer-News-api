# soccer-news-api
API (provida via GitHub Pages) do App "Soccer News"
